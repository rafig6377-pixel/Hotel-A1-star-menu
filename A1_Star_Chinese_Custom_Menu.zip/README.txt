A1 STAR CHINESE CUSTOM DIGITAL MENU

Configured WhatsApp: 9142656565 (link uses India country code +91)
Menu:
- Noodles — ₹60
- Fried Rice — ₹60
- Manchurian — ₹50

UPDATE YOUR LIVE GITHUB WEBSITE
1. Download and extract this ZIP.
2. Open your repository: Hotel-A1-star-menu.
3. Open the existing index.html and use the pencil/Edit button, or use Add file -> Upload files to replace it with this new index.html.
4. Commit changes to main.
5. Wait for GitHub Pages to redeploy, then open:
https://rafig6377-pixel.github.io/Hotel-A1-star-menu/
6. Test add/remove quantities, total, and WhatsApp order.
7. Open the live site and scan the QR with another phone before printing.

QR code is loaded from an online QR image service, so internet access is needed for it to appear.
WhatsApp opens a prefilled order message; customer must tap Send.
